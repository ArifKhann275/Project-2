<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['fullname'], $_POST['email'], $_POST['message'])) {

        // MySQL connection
        $host = "localhost";
        $username = "root";
        $password = "";
        $dbname = "arif";

        $conn = new mysqli($host, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Get and sanitize data
        $fullname = $_POST['fullname'];
        $email = $_POST['email'];
        $message = $_POST['message'];

        $stmt = $conn->prepare("INSERT INTO messages (fullname, email, message) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $fullname, $email, $message);
        $stmt->execute();

        $stmt->close();
        $conn->close();

        
        header("Location: signup.php");
        exit();
    } else {
        
        header("Location: signup.php");
        exit();
    }
} else {
    
    header("Location: signup.php");
    exit();
}
?>
