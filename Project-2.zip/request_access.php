<?php
session_start();
$conn = new mysqli("localhost", "root", "", "arif");

if (!isset($_SESSION['user_id'])) {
    echo "Please log in first.";
    exit();
}

$user_id = $_SESSION['user_id'];
$course_id = $_POST['course_id'];

// Check if already requested
$check = $conn->query("SELECT * FROM course_requests WHERE user_id = $user_id AND course_id = $course_id");

if ($check->num_rows == 0) {
    // Insert new request
    $conn->query("INSERT INTO course_requests (user_id, course_id) VALUES ($user_id, $course_id)");
    echo "Your request has been sent. Please wait for approval.";
} else {
    echo "You have already requested this course.";
}
?>
