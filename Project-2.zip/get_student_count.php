<?php
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "arif";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: ".$conn->connect_error);

$result = $conn->query("SELECT COUNT(*) AS total_students FROM users");
$row = $result->fetch_assoc();

echo $row['total_students'];
$conn->close();
?>
