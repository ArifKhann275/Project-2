import pandas as pd

# CSV লোড করো
data = pd.read_csv(r"C:\xampp\htdocs\arif\Malware dataset.csv")

# প্রথম কয়েকটা row দেখাও
print(data.head())
