<?php
session_start();
$host = "localhost";
$user = "root";
$pass = "";
$db = "arif";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $conn = new mysqli("localhost", "root", "", "arif");

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $name = $_POST['student_name'];
  $email = $_POST['student_email'];
  $title = $_POST['assignment_title'];

  $target_dir = "uploads/";
  if (!file_exists($target_dir)) {
    mkdir($target_dir, 0777, true);
  }

  $file_name = basename($_FILES["assignment_file"]["name"]);
  $target_file = $target_dir . $file_name;

  if (move_uploaded_file($_FILES["assignment_file"]["tmp_name"], $target_file)) {
    $stmt = $conn->prepare("INSERT INTO assignments (student_name, student_email, assignment_title, file_name) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $title, $file_name);

    if ($stmt->execute()) {
      $message = "✅ Assignment submitted successfully!";
    } else {
      $message = "❌ Failed to save data.";
    }

    $stmt->close();
  } else {
    $message = "❌ File upload failed.";
  }

  $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Assignment Submission</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet"/>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
      
    }

    body {
      min-height: 100vh;
  background: linear-gradient(to right, #010d1a, #032b35); /* dark gradient */
  display: flex;
  align-items: center;
  justify-content: center;
    }

    

    .container {
      width: 800px;
  background: linear-gradient(to right, #051a2f 50%, #01343d 50%); /* দুই পাশেই dark */
  border-radius: 10px;
  box-shadow: 0 0 15px #0ba3dfff;
  display: flex;
  overflow: hidden;
    }

    .form-section {
      flex: 1;
      padding: 40px;
      color: white;
    }

    .form-section h2 {
      margin-bottom: 20px;
      color: #ffffff;
      text-align: center;
    }

    .form-group {
      margin-bottom: 20px;
      position: relative;
    }

    .form-group input,
    .form-group textarea {
      width: 100%;
      padding: 10px 12px;
      background: transparent;
      border: none;
      border-bottom: 2px solid #1ac48b;
      color: white;
      font-size: 16px;
      outline: none;
    }

    .form-group label {
      position: absolute;
      top: -20px;
      margin-top: 5px;
      left: 0;
      font-size: 14px;
      color: #ffffff;
    }

    .form-group textarea {
      resize: none;
      border: 2px solid #00f7ff;
      border-radius: 5px;
    }

    .submit-btn {
      width: 100%;
      padding: 10px;
      background: #00f7ff;
      border: none;
      border-radius: 5px;
      color: #000;
      font-weight: bold;
      cursor: pointer;
      transition: 0.3s;
    }

    .submit-btn:hover {
      background: #0ae49bff;
    }

    .right-section {
      flex: 1;
      
      background: #0aa05a22;
      
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 30px;
    }

    .right-section h2 {
      color: white;
      font-size: 24px;
      margin-bottom: 10px;
    }

    .right-section p {
      font-size: 14px;
      text-align: center;
      color: #0b1114ff;
    }

    .custom-file {
      position: relative;
      display: flex;
      align-items: center;
      gap: 10px;
      background: #051a2f;
      border: 2px solid #00f7ff;
      padding: 8px 12px;
      border-radius: 5px;
      cursor: pointer;
      color: white;
      overflow: hidden;
    }

    .custom-file input[type="file"] {
      position: absolute;
      left: 0;
      top: 0;
      opacity: 0;
      height: 100%;
      width: 100%;
      cursor: pointer;
    }

    .custom-file span {
      font-size: 14px;
      color: #0be07d;
      cursor: pointer;
    }

    .message {
      text-align: center;
      margin-bottom: 15px;
      font-weight: bold;
      color: lightgreen;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="form-section">
      <h2>Submit Assignment</h2>
      <?php if ($message): ?>
        <p class="message"><?php echo $message; ?></p>
      <?php endif; ?>
      <form action="" method="POST" enctype="multipart/form-data">
        <div class="form-group">
          <label for="student_name">Student Name</label>
          <input type="text" id="student_name" name="student_name" required />
        </div>

        <div class="form-group">
          <label for="student_email">Student Email</label>
          <input type="email" id="student_email" name="student_email" required />
        </div>

        <div class="form-group">
          <label for="assignment_title">Assignment Title</label>
          <input type="text" id="assignment_title" name="assignment_title" required />
        </div>
        <br>

       <!-- Bootstrap CSS (CDN) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="form-group">
  <label for="assignment_file">Upload File</label>
  <input type="file" id="assignment_file" name="assignment_file" required />
</div>

<!-- Button -->
<button type="button" class="btn btn-primary mt-2" onclick="uploadFile()">Check Malware</button>

<!-- Result -->
<div id="result" class="mt-3"></div>

<script>
  async function uploadFile() {
    const fileInput = document.getElementById("assignment_file");
    const file = fileInput.files[0];

    if (!file) {
      alert("⚠️ Please select a file first!");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch("http://127.0.0.1:5000/upload", {
        method: "POST",
        body: formData
      });

      if (!response.ok) {
        throw new Error("Server error: " + response.status);
      }

      const result = await response.json();
      const resultElement = document.getElementById("result");

      // ✅ Prediction অনুযায়ী Bootstrap alert box
      if (result.prediction === "malware") {
        resultElement.innerHTML = `
          <div class="alert alert-danger" role="alert">
            ⚠️ Prediction: <strong>MALWARE detected!</strong>
          </div>
        `;
      } else if (result.prediction === "benign") {
        resultElement.innerHTML = `
          <div class="alert alert-success" role="alert">
            ✅ Prediction: <strong>File is SAFE (benign)</strong>
          </div>
        `;
      } else {
        resultElement.innerHTML = `
          <div class="alert alert-warning" role="alert">
            ❓ Prediction: ${result.prediction}
          </div>
        `;
      }

    } catch (err) {
      console.error(err);
      document.getElementById("result").innerHTML = `
        <div class="alert alert-warning" role="alert">
          ⚠️ Error connecting to API
        </div>
      `;
    }
  }
</script>






      



        <button type="submit" class="submit-btn">Submit</button>
      </form>
    </div>

    <div class="right-section">
      <h2>WELCOME!</h2>
      <p>Submit your assignment easily with this stylish and modern form.</p>
    </div>
  </div>

  <script>
    const fileInput = document.getElementById("assignment_file");
    const fileNameDisplay = document.getElementById("file-name");

    fileInput.addEventListener("change", function () {
      if (fileInput.files.length > 0) {
        fileNameDisplay.textContent = fileInput.files[0].name;
      } else {
        fileNameDisplay.textContent = "No file chosen";
      }
    });
  </script>
</body>
</html>
