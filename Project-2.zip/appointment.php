<?php
// Start session (optional, for future use)
session_start();

// Enable error reporting for MySQLi
ini_set('display_errors', 1);
error_reporting(E_ALL);

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Database connection
$host = "localhost";
$username = "root";
$password = ""; // default for XAMPP/WAMP
$dbname = "arif";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $department = $conn->real_escape_string($_POST['department']);
    $doctor = $conn->real_escape_string($_POST['doctor']);
    $date = $conn->real_escape_string($_POST['date']);
    $message = $conn->real_escape_string($_POST['message']);

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "❌ Invalid email format.";
        exit;
    }

    // Validate required fields
    if (empty($name) || empty($email) || empty($phone) || empty($department) || empty($doctor) || empty($date)) {
        echo "❌ All fields are required!";
        exit;
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO appointments (name, email, phone, department, doctor, date, message) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $email, $phone, $department, $doctor, $date, $message);

    // Execute
    if ($stmt->execute()) {
        // Redirect after success
        header("Location: index.html");
        exit;
    } else {
        echo "❌ Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
