<?php
// Start session (optional, for future use)
session_start();

// Enable error reporting for MySQLi
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Database connection
$host = "localhost";
$username = "root";
$password = ""; // default for XAMPP/WAMP
$dbname = "dusto";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $department = $conn->real_escape_string($_POST['department']);
    $doctor = $conn->real_escape_string($_POST['doctor']);
    $date = $conn->real_escape_string($_POST['date']);
    $message = $conn->real_escape_string($_POST['message']);

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO appointments (name, email, phone, department, doctor, date, message) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $email, $phone, $department, $doctor, $date, $message);

    // Execute
    if ($stmt->execute()) {
        echo "✅ Appointment booked successfully!";
    } else {
        echo "❌ Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<style>
        /* ===== Global Styles ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        :root {
            --primary: #87CEEB;       /* Sky Blue */
            --secondary: #4682B4;     /* Steel Blue */
            --accent: #00BFFF;        /* Deep Sky Blue */
            --bg-white: #FFFFFF;
            --card-bg: #F0F8FF;       /* Alice Blue */
            --text-dark: #333333;
        }
        
        body {
            background: var(--bg-white);
            color: var(--text-dark);
            line-height: 1.6;
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* ===== Header & Navigation ===== */
        header {
            background: var(--secondary);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .logo {
            font-size: 28px;
            font-weight: 700;
            color: white;
        }
        
        .logo span {
            color: var(--accent);
        }
        
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .nav-links {
            display: flex;
            list-style: none;
        }
        
        .nav-links li {
            margin-left: 30px;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: 0.3s;
        }
        
        .nav-links a:hover {
            color: var(--accent);
        }
        
        .btn {
            display: inline-block;
            background: var(--primary);
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 600;
            transition: 0.3s;
            border: none;
            cursor: pointer;
        }
        
        .btn:hover {
            background: var(--accent);
            transform: translateY(-2px);
        }
        
        /* ===== Hero Section ===== */
        .hero {
            padding: 120px 0;
            text-align: center;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            position: relative;
        }
        
        .hero-content {
            position: relative;
            z-index: 1;
        }
        
        .hero h1 {
            font-size: 48px;
            margin-bottom: 20px;
        }
        
        .hero p {
            font-size: 20px;
            margin-bottom: 30px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
        
        /* ===== Services Section ===== */
        .services {
            padding: 80px 0;
            background: var(--bg-white);
        }
        
        .section-title {
            text-align: center;
            margin-bottom: 50px;
        }
        
        .section-title h2 {
            font-size: 36px;
            color: var(--secondary);
            margin-bottom: 15px;
        }
        
        .section-title p {
            color: var(--text-dark);
            font-size: 18px;
        }
        
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .service-card {
            background: var(--card-bg);
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            transition: 0.3s;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid rgba(70, 130, 180, 0.1);
        }
        
        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .service-card i {
            font-size: 50px;
            color: var(--secondary);
            margin-bottom: 20px;
        }
        
        .service-card h3 {
            font-size: 24px;
            margin-bottom: 15px;
            color: var(--secondary);
        }
        
        /* ===== Doctors Section ===== */
        .doctors {
            padding: 80px 0;
            background: var(--card-bg);
        }
        
        .doctors-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }
        
        .doctor-card {
            background: var(--bg-white);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: 0.3s;
        }
        
        .doctor-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .doctor-img {
            height: 250px;
            overflow: hidden;
        }
        
        .doctor-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: 0.5s;
        }
        
        .doctor-card:hover .doctor-img img {
            transform: scale(1.1);
        }
        
        .doctor-info {
            padding: 20px;
            text-align: center;
        }
        
        .doctor-info h3 {
            font-size: 22px;
            margin-bottom: 5px;
            color: var(--secondary);
        }
        
        .doctor-info p {
            color: var(--text-dark);
            margin-bottom: 15px;
        }
        
        /* ===== Appointment Section ===== */
        .appointment {
            padding: 80px 0;
            background: var(--bg-white);
        }
        
        .appointment-form {
            max-width: 600px;
            margin: 0 auto;
            background: var(--card-bg);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--secondary);
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        
        .form-group textarea {
            height: 120px;
        }
        
        /* ===== Footer ===== */
        footer {
            background: var(--secondary);
            color: white;
            padding: 50px 0 20px;
        }
        
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .footer-column h3 {
            font-size: 22px;
            margin-bottom: 20px;
            color: var(--accent);
        }
        
        .footer-column p,
        .footer-column a {
            color: #ddd;
            margin-bottom: 10px;
            display: block;
            text-decoration: none;
            transition: 0.3s;
        }
        
        .footer-column a:hover {
            color: var(--accent);
        }
        
        .social-links {
            display: flex;
            gap: 15px;
        }
        
        .social-links a {
            color: white;
            font-size: 20px;
        }
        
        .social-links a:hover {
            color: var(--accent);
        }
        
        .copyright {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: #ddd;
        }
        
        /* ===== Responsive Adjustments ===== */
        @media (max-width: 768px) {
            .nav-links {
                display: none;
            }
            
            .hero h1 {
                font-size: 36px;
            }
            
            .hero p {
                font-size: 18px;
            }
        }
    </style>
<!-- HTML Form -->
<section class="appointment" id="appointment">
    <div class="container">
        <div class="section-title">
            <h2>Book an Appointment</h2>
            <p>Fill out the form below to schedule a visit with our specialists.</p>
        </div>
        <div class="appointment-form">
            <form id="appointmentForm" action="appointment.php" method="POST">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" placeholder="Your Name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Your Email" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" placeholder="Your Phone" required>
                </div>
                <div class="form-group">
                    <label for="department">Department</label>
                    <select id="department" name="department" required>
                        <option value="">Select Department</option>
                        <option value="cardiology">Cardiology</option>
                        <option value="neurology">Neurology</option>
                        <option value="orthopedics">Orthopedics</option>
                        <option value="pediatrics">Pediatrics</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="doctor">Preferred Doctor</label>
                    <select id="doctor" name="doctor" required>
                        <option value="">Select Doctor</option>
                        <option value="dr-sarah">Dr. Ayesha Siddika</option>
                        <option value="dr-michael">Dr. Hassan Mahmud</option>
                        <option value="dr-lisa">Dr. Shafiqul Islam</option>
                        <option value="dr-david">Dr. Nusrat Jahan</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="date">Appointment Date</label>
                    <input type="date" id="date" name="date" required>
                </div>
                <div class="form-group">
                    <label for="message">Additional Message</label>
                    <textarea id="message" name="message" placeholder="Your Message"></textarea>
                </div>
                <button type="submit" class="btn">Submit Request</button>
            </form>
        </div>
    </div>
</section>

