const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const OpenAI = require("openai"); // v4+ CommonJS

const app = express();
app.use(bodyParser.json());
app.use(cors({ origin: 'http://localhost' }));

// ⚠️ OpenAI API key
const openai = new OpenAI({
  apiKey: "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"
});

// POST route for chatbot
app.post('/chat', async (req, res) => {
  const userMessage = req.body.message;
  if (!userMessage) return res.json({ reply: "No message received." });

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: userMessage }]
    });

    const reply = completion.choices[0].message.content;
    res.json({ reply });

  } catch (err) {
    console.error('Server error:', err);
    res.json({ reply: "Server error. Please try again later." });
  }
});

// Optional test route
app.get('/', (req, res) => res.send('Node.js Chatbot server running.'));

app.listen(5000, () => console.log('Server running on port 5000'));
