<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "arif";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// ------------------- LOGIN (signin) -------------------
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // ইউজার ডাটা নিন
    $stmt = $conn->prepare("SELECT id, username, password, profile_photo, failed_attempts, lock_until FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($userId, $username, $hashedPassword, $profilePhoto, $failedAttempts, $lockUntil);

    if ($stmt->fetch()) {
        $stmt->close();

        // 🔒 লক চেক
        if ($lockUntil !== null && strtotime($lockUntil) > time()) {
            $remaining = ceil((strtotime($lockUntil) - time()) / 60);
            exit("Account is locked. Try again after {$remaining} minute(s).");
        }

        // ✅ সঠিক পাসওয়ার্ড
        if (password_verify($password, $hashedPassword)) {
            $_SESSION['email'] = $email;
            $_SESSION['username'] = $username;
            $_SESSION['profile_photo'] = $profilePhoto;

            // ভুল কাউন্টার রিসেট করুন
            $reset = $conn->prepare("UPDATE users SET failed_attempts = 0, lock_until = NULL, last_failed_at = NULL WHERE id = ?");
            $reset->bind_param("i", $userId);
            $reset->execute();
            $reset->close();

            header("Location: profile.php");
            exit();
        } 
        // ❌ ভুল পাসওয়ার্ড
        else {
            $stmt->close();

            $failedAttempts++;
            $lockUntilValue = null;
            $LOCK_THRESHOLD = 3;   // ৩ বার ভুল হলে লক
            $LOCK_MINUTES   = 15;  // কত মিনিট লক থাকবে

            if ($failedAttempts >= $LOCK_THRESHOLD) {
                $lockUntilValue = date("Y-m-d H:i:s", strtotime("+{$LOCK_MINUTES} minutes"));
            }

            $update = $conn->prepare("UPDATE users SET failed_attempts = ?, lock_until = ?, last_failed_at = NOW() WHERE id = ?");
            $update->bind_param("isi", $failedAttempts, $lockUntilValue, $userId);
            $update->execute();
            $update->close();

            if ($lockUntilValue) {
                exit("Too many failed attempts. Account locked for {$LOCK_MINUTES} minutes.");
            } else {
                $remaining = $LOCK_THRESHOLD - $failedAttempts;
                exit("Wrong password. {$remaining} attempt(s) left.");
            }
        }
    } else {
        $stmt->close();
        exit("User not found!");
    }
}

// ------------------- SIGNUP -------------------
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['signup'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $email, $password);

    if ($stmt->execute()) {
        echo "Signup successful!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SKILL HUB</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="valo.css">
   


    <style>
        body {
            font-family: Arial, sans-serif;
            transition: background 0.3s, color 0.3s;
        }
        .dark-theme {
            background: #383a3b;
            color: white;
            .box{
                background: #2c2f30;

            }
            
            .courses .swiper-slide{
                background: #2c2f30;
            }
            .review-card{
                background: #2c2f30;
            }
            .teachers .swiper-slide{
                background: transparent;
            }
            .container .contactform::after{
                background: #2c2f30;
            }
            .navbar{
                background-color: #2c2f30;
            }
            
        }
        .light-theme {
            background: #032917;
            color: #ffffff;
            .box{
                background: #0f492c; 
            }
            .courses .swiper-slide{
                background: #0f492c;

            }
            
            .review-card{
                background: #0f492c;
            }
            .teachers .swiper-slide{
                background: transparent;
            }
            .container .contactform::after{
                background: #0f492c;
            }
            .navbar{
                background-color:rgb(5, 75, 37);
            }
        }
        
    </style>


</head>
<body class="homepage">
    <div class="navbar">
        <div class="logo"> <b>SKILL HUB</b></div>
        <button class="menu-button" onclick="toggleMenu()">&#9776;</button>
        <div class="menu" id="menu">
            <a href="#">Home</a>
            <a href="#courses">Courses</a>
            <a href="#teachers">Teachers</a>
            <a href="#reviews">Reviews</a>
            <button class="toggle-btn" onclick="toggleTheme()">🌙</button>
            <?php 
            

            if (isset($_SESSION['email'])): ?>
            <a href="profile.php" style="white-space: nowrap; font-size: 20px;">
            <?php if (isset($_SESSION['profile_photo']) && !empty($_SESSION['profile_photo'])): ?>
            <img src="<?php echo $_SESSION['profile_photo']; ?>" 
                alt="Profile" 
                style="width: 37px; height: 34px; border-radius: 50%; vertical-align: middle; object-fit: cover; margin-top:-10px">

            <?php else: ?>
            <i style="font-size: 23px;">👤</i>
            <?php endif; ?>
        </a>
        <?php else: ?>
        <a href="#" id="openModal" style="white-space: nowrap;">Sign in</a>
        <?php endif; ?>
                

            
            

            
            
            
        </div>
    </div>


    <?php if ($success_message): ?>
        <div class="success-message"><?php echo $success_message; ?></div>
    <?php endif; ?>



    

    <script>
        const modal = document.getElementById("authModal");
        const openModal = document.getElementById("openModal");
        const closeModal = document.getElementById("closeModal");
    
        const signInForm = document.getElementById("signInForm");
        const signUpForm = document.getElementById("signUpForm");
    
        const showSignUp = document.getElementById("showSignUp");
        const showSignIn = document.getElementById("showSignIn");
    
        openModal.onclick = () => {
          modal.style.display = "flex";
          signInForm.classList.add("active");
          signUpForm.classList.remove("active");
        };
    
        closeModal.onclick = () => {
          modal.style.display = "none";
        };
    
        showSignUp.onclick = () => {
          signInForm.classList.remove("active");
          signUpForm.classList.add("active");
        };
    
        showSignIn.onclick = () => {
          signUpForm.classList.remove("active");
          signInForm.classList.add("active");
        };
    
        // Optional: Close modal when clicking outside
        window.onclick = (e) => {
          if (e.target === modal) {
            modal.style.display = "none";
          }
        };
      </script>
    
   
    



    
    
    <section class="home" id="home">
        <div class="row">
            <div class="content">
                
                <h1><span style="color: white;">Online</span><br> <span style="color: #00E77F;">Education</span></h1>
                
            </div>
            <div class="image">
                <img src="untitile.png" alt="">
            </div>
        </div>
    </section>
    
    <section class="count">
        <div class="box">
            <i class="fas fa-graduation-cap"></i>
            <div class="content">
                <h3 data-target="150">0</h3>
                <p>courses</p>
            </div>
        </div>
    
        <div class="box">
            <i class="fas fa-user-graduate"></i>
            <div class="content">
                 <div style="font-size: 24px; margin: 10px 0; font-weight: bold;" id="student-count">0 </div> 
             <!-- placeholder -->

<script>
function loadStudentCount() {
    fetch("get_student_count.php")
        .then(response => response.text())
        .then(data => {
            document.getElementById("student-count").innerText = data;
        })
        .catch(error => console.error("Error loading student count:", error));
}

// Load on page ready
document.addEventListener("DOMContentLoaded", loadStudentCount);

// Reload count whenever user logs in or out
document.addEventListener("userLogin", loadStudentCount);
document.addEventListener("userLogout", loadStudentCount);
</script>
                <p>students</p>
            </div>
        </div>
        
        


    
        <div class="box">
            <i class="fas fa-chalkboard-user"></i>
            <div class="content">
                <h3 data-target="80">0</h3>
                <p>teachers</p>
            </div>
        </div>
    
        <div class="box">
            <i class="fas fa-face-smile"></i>
            <div class="content">
                <h3 data-target="97">0 </h3>
                <p>satisfaction</p>
            </div>
        </div>
    </section>

    <script>
// Courses count animation
const counters = document.querySelectorAll("h3");
function startCoursesCounting() {
    counters.forEach(counter => {
        const target = +counter.getAttribute("data-target");
        counter.innerText = 0;
        const increment = target / 100;

        function updateCount() {
            let count = +counter.innerText;
            if (count < target) {
                counter.innerText = Math.ceil(count + increment);
                setTimeout(updateCount, 20);
            } else {
                counter.innerText = target;
            }
        }
        updateCount();
    });
}

// Student count animation
function startStudentCounting(target) {
    const counter = document.getElementById("student-count");
    counter.innerText = 0;
    const increment = target / 100;

    function updateCount() {
        let count = +counter.innerText;
        if (count < target) {
            counter.innerText = Math.ceil(count + increment);
            setTimeout(updateCount, 20);
        } else {
            counter.innerText = target;
        }
    }
    updateCount();
}

// AJAX fetch student count
function loadStudentCount() {
    fetch("get_student_count.php?t=" + new Date().getTime())
        .then(response => response.text())
        .then(data => {
            const totalStudents = +data;
            startStudentCounting(totalStudents);
        })
        .catch(error => console.error("Error loading student count:", error));
}

// Page load
window.addEventListener("load", () => {
    startCoursesCounting();
    loadStudentCount();
});

// Back/forward navigation
window.addEventListener("pageshow", () => {
    startCoursesCounting();
    loadStudentCount();
});

// After login/signup, fresh student count
function afterLoginOrLogout() {
    loadStudentCount();
}

// Example: form submit এর পরে fresh count দেখাতে
document.querySelector("#signInForm form")?.addEventListener("submit", () => {
    setTimeout(afterLoginOrLogout, 500);
});
document.querySelector("#signUpForm form")?.addEventListener("submit", () => {
    setTimeout(afterLoginOrLogout, 500);
});
</script>

   



    <script src="script.js"></script>

    <section class="courses" id="courses">
        <h1 class="heading">Our <span>courses</span></h1>

        <div class="swiper-container">
            
            <div class="swiper-wrapper">
            <div class="swiper-slide">
                    <img src="course 1.png" alt="Course Image" class="course-image">
                    <div class="course-content">
                    <h2 class="course-title">HTML</h2>
                    
                    <div class="course-review">
                        <span class="stars">★★★★★</span>
                        <span class="review-text">( 99 Review )</span>
                        <div class="left">
                            <i class="icon" style="font-size: 21px;">👥</i>
                            <span style="margin-left: 5px; color: #ffffff; font-weight: bold; margin-top: 9px;">245</span>
                          </div>
                    </div>
                    <div class="course-footer">
                        <span class="price">Free*</span>

                        
                                <a href="course1.html" class="enroll-button">Take the Courses</a>
                        
                        
                        
                        
                    </div>
                    </div>
                      
                      
                    
                </div>

                <div class="swiper-slide">
                    <img src="course 2.png" alt="Course Image" class="course-image">
                    <div class="course-content">
                    <h2 class="course-title">JavaScript</h2>
                    
                    <div class="course-review">
                        <span class="stars">★★★★★</span>
                        <span class="review-text">( 97 Review )</span>
                        <div class="left">
                            <i class="icon" style="font-size: 21px;">👥</i>
                            <span style="margin-left: 5px; color: #ffffff; font-weight: bold; margin-top: 9px;">187</span>
                          </div>
                    </div>
                    <div class="course-footer">
                        <span class="price">Free*</span>
                        
                        <a href="course2.html" class="enroll-button">Take the Courses</a>
                        
                    </div>
                    </div>
                      
                      
                    
                </div>

                <div class="swiper-slide">
                    <img src="course6.png" alt="Course Image" class="course-image">
                    <div class="course-content">
                    <h2 class="course-title">NoteJS</h2>
                    
                    <div class="course-review">
                        <span class="stars">★★★★★</span>
                        <span class="review-text">( 48 Review )</span>
                        <div class="left">
                            <i class="icon" style="font-size: 21px;">👥</i>
                            <span style="margin-left: 5px; color: #ffffff; font-weight: bold; margin-top: 9px;">159</span>
                          </div>
                    </div>
                    <div class="course-footer">
                        <span class="price">Free*</span>
                        
                        <a href="course3.html" class="enroll-button">Take the Courses</a>
                        
                    </div>
                    </div>
                      
                      
                    
                </div>

                <div class="swiper-slide">
                    <img src="course 4.png" alt="Course Image" class="course-image">
                    <div class="course-content">
                    <h2 class="course-title">BootStrap</h2>
                    
                    <div class="course-review">
                        <span class="stars">★★★★★</span>
                        <span class="review-text">( 53 Review )</span>
                        <div class="left">
                            <i class="icon" style="font-size: 21px;">👥</i>
                            <span style="margin-left: 5px; color: #ffffff; font-weight: bold; margin-top: 9px;">94</span>
                          </div>
                    </div>
                    <div class="course-footer">
                        <span class="price">Free*</span>
                        
                        <a href="course4.html" class="enroll-button">Take the Courses</a>
                        
                    </div>
                    </div>
                      
                      
                    
                </div>

                <div class="swiper-slide">
                    <img src="course 5.png" alt="Course Image" class="course-image">
                    <div class="course-content">
                    <h2 class="course-title">SQL</h2>
                    
                    <div class="course-review">
                        <span class="stars">★★★★★</span>
                        <span class="review-text">( 69 Review )</span>
                        <div class="left">
                            <i class="icon" style="font-size: 21px;">👥</i>
                            <span style="margin-left: 5px; color: #ffffff; font-weight: bold; margin-top: 9px;">162</span>
                          </div>
                    </div>
                    <div class="course-footer">
                        <span class="price">Free*</span>
                        
                        <a href="course5.html" class="enroll-button">Take the Courses</a>
                        
                    </div>
                    </div>
                    
                </div>

                <div class="swiper-slide">
                    <img src="course 3.png" alt="Course Image" class="course-image">
                    <div class="course-content">
                    <h2 class="course-title">PHP</h2>
                    
                    <div class="course-review">
                        <span class="stars">★★★★★</span>
                        <span class="review-text">( 89 Review )</span>
                        <div class="left">
                            <i class="icon" style="font-size: 21px;">👥</i>
                            <span style="margin-left: 5px; color: #ffffff; font-weight: bold; margin-top: 9px;">231</span>
                          </div>
                    </div>
                    <div class="course-footer">
                        <span class="price">Free*</span>
                        
                        <a href="course6.html" class="enroll-button">Take the Courses</a>
                        
                    </div>
                    </div>
                    
                </div>


                <div class="swiper-pagination"></div>
                

            </div>
            <div class="swiper-pagination"></div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    </section>


    <section class="teachers" id="teachers">
  <h2 class="heading">Expert <span>tutors</span></h2><br>
  <div class="swiper-container1">
    <div class="swiper-wrapper">

      <div class="swiper-slide">
        <div class="img-wrap">
          <img src="Teacher 1.jpeg" alt="">
          <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
          </div>
        </div>
        <h3>Albert Einstein</h3>
      </div>

      <div class="swiper-slide">
        <div class="img-wrap">
          <img src="Teacher 2.jpeg" alt="">
          <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
          </div>
        </div>
        <h3>Nikola Tesla</h3>
      </div>

      <div class="swiper-slide">
        <div class="img-wrap">
          <img src="Teacher 3.jpeg" alt="">
          <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
          </div>
        </div>
        <h3>Isaac Newton</h3>
      </div>

      <div class="swiper-slide">
        <div class="img-wrap">
          <img src="Teacher 4.jpeg" alt="">
          <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
          </div>
        </div>
        <h3>Marie Curie</h3>
      </div>

      <div class="swiper-slide">
        <div class="img-wrap">
          <img src="Teacher 5.jpeg" alt="">
          <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-whatsapp"></a>
          </div>
        </div>
        <h3>Natasha Stott Despoja</h3>
      </div>

    </div>
    <div class="swiper-pagination"></div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
</section>


    <script>
        var swiper = new Swiper(".swiper-container", {
        slidesPerView: 3, 
    spaceBetween: 70,  
    centeredSlides: true, 
    loop: true,
    
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },

    // Responsive breakpoints
    breakpoints: {
        1024: {  // Desktop
            slidesPerView: 3,
            spaceBetween: 40
        },
        768: {   // Tablet
            slidesPerView: 2,
            spaceBetween: 20
        },
        480: {   // Mobile
            slidesPerView: 1,
            spaceBetween: 10
        }
    }
    });
    
      </script>


    
<script>
    var swiper = new Swiper(".swiper-container1", {
    slidesPerView: 3, 
    spaceBetween: 20,  
    centeredSlides: true, 
    loop: true,
    
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },

    // Responsive breakpoints
    breakpoints: {
        1024: {  // Desktop
            slidesPerView: 3,
            spaceBetween: 40
        },
        768: {   // Tablet
            slidesPerView: 2,
            spaceBetween: 20
        },
        480: {   // Mobile
            slidesPerView: 1,
            spaceBetween: 10
        }
    }
});


  </script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

  




<h2 class="heading">Student's <span>reviews</span></h2>
<div class="swiper-container2" id="reviews">
    
    <div class="swiper-wrapper">
        
        <!-- Review Card 1 -->
        
        <div class="swiper-slide review-card">
            <p class="review-text">
            The teacher are more beautiful than the course content itself 🥰 .
            I am fully satisfied <br>
                
            </p>
            <div class="review-footer">
                <img src="r11.png" class="profile-pic">
                <div>
                    <p class="name">Dipok Sorkar</p>
                    <div class="stars">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Review Card 2 -->
        <div class="swiper-slide review-card">
            <p class="review-text">
            An excellent e-learning course that simplifies complex concepts with clarity.
            </p>
            <div class="review-footer">
                <img src="r2.png" class="profile-pic">
                <div>
                    <p class="name">Tabassum Soha</p>
                    <div class="stars">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-alt"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Review Card 3 -->
        <div class="swiper-slide review-card">
            <p class="review-text">
            দূর, এটা কোনো course হইলো।আমি A B C পারি না।  এসব কি পড়মু।  এটা হইলো বেটা 
            </p>
            <div class="review-footer">
                <img src="r3.png" class="profile-pic">
                <div>
                    <p class="name">Hero Alam</p>
                    <div class="stars">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-alt"></i>
                        
                    </div>
                </div>
            </div>
        </div>

        <div class="swiper-slide review-card">
            <p class="review-text">
                Consectetur Adipisicing Elit. Illum <br>
                Necessitatibus Atque Fuga Delectus.
            </p>
            <div class="review-footer">
                <img src="r4.jpeg" class="profile-pic">
                <div>
                    <p class="name">Jannat</p>
                    <div class="stars">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-alt"></i>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Swiper Navigation Buttons -->
    

    <!-- Swiper Pagination -->
    <div class="swiper-pagination"></div>
</div>
</div>

<section class="contact">
    <div class="content">
        <h2 class="heading"> <span>Contact</span> us</h2>

        
    </div>
    <div class="container">
        <div class="contactinfo">
            
                <div class="box2">
                    <div class="icon2"><b></b><i class="fa-solid fa-house fa-sm"></i></div>
                    <div class="text2">
                        <h3>Address</h3>
                        <p> Holding 77 Beribadh Road, Dhaka</p>
                    </div>
                </div>

                <div class="box2">
                    <div class="icon2"><b></b><i class="fa-solid fa-phone fa-sm"></i></div>
                    <div class="text2">
                        <h3>Phone</h3>
                        <p> 01987654321</p>
                    </div>
                </div>

                <div class="box2">
                    <div class="icon2"><b></b><i class="fa-solid fa-envelope fa-sm"></i></div>
                    <div class="text2">
                        <h3>Email</h3>
                        <p>thisisdusto@gmail.com</p>
                    </div>
                </div>

                <h2 class="txt">Connect with us</h2>
                <ul class="sci">
                    <li><a href="#"><i class="fa-brands fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa-brands fa-youtube"></i></a></li>
                </ul>

            
        </div>
        <div class="contactform">
        <form method="POST" action="submit.php">
            <div class="inputbox">
            <input type="text" name="fullname" required="required">
            <span>Full Name</span>
        </div>
        <div class="inputbox">
            <input type="email" name="email" required="required">
            <span>Email</span>
        </div>
        <div class="inputbox">
            <textarea name="message" required="required"></textarea>
            <span>Type your Message</span>
        </div>
        <div class="inputbox">
            <input type="submit" value="Send">
        </div>
    </form>

        </div>
            
    </div>
</section>





<script>
    var swiper = new Swiper(".swiper-container2", {
    slidesPerView: 3, 
    spaceBetween: 20,  
    centeredSlides: false,  // ✅ এটা false করুন
    loop: true,
    
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },

    // Responsive breakpoints
    breakpoints: {
        1024: {  // Desktop
            slidesPerView: 3,
            spaceBetween: 30
        },
        768: {   // Tablet
            slidesPerView: 2,
            spaceBetween: 20
        },
        480: {   // Mobile
            slidesPerView: 1,
            spaceBetween: 10
        }
    }
});


    
</script>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    
    <script src="wow.js"></script>

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script>
        function toggleMenu() {
            var menu = document.getElementById("menu");
            menu.classList.toggle("show");
        }

        function toggleTheme() {
            let body = document.body;
            let currentTheme = body.classList.contains('dark-theme') ? 'dark' : 'light';
            let newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            
            body.classList.remove(`${currentTheme}-theme`);
            body.classList.add(`${newTheme}-theme`);
            
            localStorage.setItem('theme', newTheme);
        }
        
        // Apply saved theme on page load
        (function () {
            let savedTheme = localStorage.getItem('theme') || 'light';
            document.body.classList.add(`${savedTheme}-theme`);
        })();
    </script>

    <a href="logout.php">Logout</a>


    <style>




.container .contactform form{
    position: relative;
    z-index: 10;
}
.container .contactform form h2{
    font-size: 2em;
    color: #ffffff;
    font-weight: 500;

}
.container .contactform form .inputbox{
    position: relative;
    width: 100%;
    margin-top: 30px;
}
.container .contactform form .inputbox input,
.container .contactform form .inputbox textarea{
    width: 100% !important;
    padding: 10px 0 5px 0;
    font-size: 1.1em;
    margin: 10px 0;
    border: none;
    background: transparent;
    border-bottom: 2px solid #01dbc2;
    color: #fff;
    outline: none;
    resize: none;
}
.container .contactform form .inputbox span{
    position: absolute;
    left: 0;
    top: 18px;
    pointer-events: none;
    padding: 0px 0;
    
    margin: 10px 0;
    font-size: 1.1em;
    color:rgb(15, 211, 90);
    transition: 0.3s;


}
.container .contactform form .inputbox input:focus ~ span,
.container .contactform form .inputbox textarea:focus ~ span,
.container .contactform form .inputbox input:valid ~ span,
.container .contactform form .inputbox textarea:valid ~ span{
    color: #01dbc2;
    font-size: 0.9em;
    transform: translateY(-30px);
}
.container .contactform form .inputbox input[type="submit"]{
    width: 100%;
    background: #01dbc2;
    color: #222;
    border: none;
    cursor: pointer;
    padding: 10px;

}
    </style>


    
</body>
</html>

